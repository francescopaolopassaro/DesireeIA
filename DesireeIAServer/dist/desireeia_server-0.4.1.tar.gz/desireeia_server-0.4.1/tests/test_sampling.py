"""Sampling map: OpenAI JSON -> engine knobs, with rejection of unsupported fields."""

from __future__ import annotations

import pytest

from desireeiaserver.api.errors import InvalidRequestError, NotSupportedError
from desireeiaserver.config import Settings
from desireeiaserver.sampling import resolve


def test_resolve_maps_fields():
    params = resolve({
        "temperature": 0.8,
        "top_k": 50,
        "top_p": 0.9,
        "frequency_penalty": 0.1,
        "presence_penalty": 0.2,
        "repeat_penalty": 1.2,
        "seed": 42,
        "stop": "END",
        "max_tokens": 100,
        "stream": True,
    })
    assert params.temperature == 0.8
    assert params.top_k == 50
    assert params.top_p == 0.9
    assert params.frequency_penalty == 0.1
    assert params.presence_penalty == 0.2
    assert params.repeat_penalty == 1.2
    assert params.seed == 42
    assert params.stop == ["END"]
    assert params.max_tokens == 100
    assert params.stream is True


def test_resolve_stop_list():
    assert resolve({"stop": ["a", "b"]}).stop == ["a", "b"]


def test_rejects_unsupported_sampling_fields():
    for field in ("mirostat", "typical_p"):
        with pytest.raises(NotSupportedError):
            resolve({field: 0.1})


def test_logprobs_are_resolved_and_validated():
    off = resolve({})
    assert off.logprobs is False and off.top_logprobs == 0
    p = resolve({"logprobs": True, "top_logprobs": 3})
    assert p.logprobs is True and p.top_logprobs == 3
    assert resolve({"logprobs": True}).top_logprobs == 0
    for bad in ({"logprobs": True, "top_logprobs": 17}, {"logprobs": True, "top_logprobs": -1}, {"top_logprobs": 2},
                {"logprobs": True, "top_logprobs": "x"}, {"logprobs": "yes"}):
        with pytest.raises(InvalidRequestError):
            resolve(bad)


def test_several_answers_are_allowed_but_not_streamed():
    assert resolve({"n": 3}).n == 3
    with pytest.raises(NotSupportedError):
        resolve({"n": 2, "stream": True})
    with pytest.raises(InvalidRequestError):
        resolve({"n": 99})
    with pytest.raises(NotSupportedError):
        resolve({"best_of": 3})


def test_rejects_bad_types():
    with pytest.raises(InvalidRequestError):
        resolve({"temperature": "hot"})
    with pytest.raises(InvalidRequestError):
        resolve({"top_k": 3.5})
    with pytest.raises(InvalidRequestError):
        resolve({"n": 0})


def test_max_tokens_resolution():
    assert resolve({"max_tokens": 100}).generation_max_tokens(Settings()) == 100
    assert resolve({}).generation_max_tokens(Settings(n_predict=256)) == 256
    assert resolve({"max_tokens": 0}).generation_max_tokens(Settings()) == 2048


def test_n_predict_allowed_in_native_mode():
    params = resolve({"n_predict": 128}, allow_n_predict=True)
    assert params.n_predict == 128
    assert params.generation_max_tokens(Settings()) == 128

def test_engine_extras_are_read_from_the_request():
    p = resolve({"min_p": 0.05, "dry_multiplier": 0.8, "reasoning_budget": 256})
    assert (p.min_p, p.dry_multiplier, p.reasoning_budget) == (0.05, 0.8, 256)
    q = resolve({})
    assert (q.min_p, q.dry_multiplier, q.reasoning_budget) == (None, None, None)
